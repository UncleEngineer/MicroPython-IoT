import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:iotapp/sensor.dart';
import 'package:http/http.dart' as http;

class SinglePage extends StatefulWidget {
  const SinglePage({super.key, required this.censorCode});
  final String censorCode;

  @override
  State<SinglePage> createState() => _SinglePageState();
}

class _SinglePageState extends State<SinglePage> {
  late String censorCode;
  late Future<Sensor> censorData;
  var baseURL = Sensor.baseURL;

  Future<Sensor> getCensorData() async {
    final url =
        Uri.http(baseURL, '/sensor-current-single/$censorCode');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return Sensor.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
    } else {
      throw Exception('Failed');
    }
  }

  @override
  void initState() {
    censorCode = widget.censorCode;
    censorData = getCensorData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Single Data $censorCode'),
      ),
      body: singleData(),
    );
  }

  Widget singleData() {
    return FutureBuilder(
        future: censorData,
        builder: ((context, snapshot) {
          if (snapshot.hasData) {
            return Column(
              children: [
                Text(
                  'Censor Code : ${snapshot.data!.code}',
                  style: const TextStyle(fontSize: 20),
                ),
                Text(
                  'Title : ${snapshot.data!.title}',
                  style: const TextStyle(fontSize: 20),
                ),
                Text(
                  'Temperature : ${snapshot.data!.temperature}',
                  style: const TextStyle(fontSize: 20),
                ),
                Text(
                  'Humidity : ${snapshot.data!.humidity}',
                  style: const TextStyle(fontSize: 20),
                ),
                Text(
                  'Timestamp : ${snapshot.data!.timestamp}',
                  style: const TextStyle(fontSize: 20),
                )
              ],
            );
          }else{
            return const Center(child: CircularProgressIndicator());
          }
        }));
  }
}
