import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:iotapp/multipage.dart';
import 'package:iotapp/sensor.dart';
import 'package:iotapp/singlepage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IoT Censor App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'IoT Censor App'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  List censorList = [];
  var baseURL = Sensor.baseURL;
  var searchCtrl = TextEditingController();
  bool runState = false;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<List<Sensor>> searchCensorData() async {
    List<Sensor> censorMulti = [];
    List<Sensor> censorFromJson(String body) => List<Sensor>.from(jsonDecode(body).map((x) => Sensor.fromJson(x)));

    final url = Uri.http(baseURL, '/sensor-current-multiple/${searchCtrl.text}');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      var resBody = censorFromJson(utf8.decode(response.bodyBytes));

      for (var item in resBody){
        censorMulti.add(item);
      }

    } else {
      throw Exception('Failed');
    }
    return censorMulti;
  }

  @override
  void initState(){
    super.initState();
    getCensorList();
  }

  Future<void> getCensorList() async{
    var url = Uri.http(baseURL,'/sensor-list');
    var response = await http.get(url);
    if (response.statusCode == 200 && response.body.isNotEmpty){
      // var result = json.decode(response.body);
      var result = utf8.decode(response.bodyBytes);
      setState(() {
        censorList = jsonDecode(result);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> _widgetOptions = <Widget>[
      censorSingleListTab(),
      censorMultiListTab(),
      searchFormTab()
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('IoT Censor App'),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Single Data',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business),
            label: 'Multi Data',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Search',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }

  Widget censorSingleListTab() {
    return ListView.builder(
        itemCount: censorList.isEmpty ? 0 : censorList.length,
        itemBuilder: ((context, index) {
          return Card(
            child: ListTile(
              title: Text(censorList[index]),
              onTap: (() {
                Navigator.push(context, MaterialPageRoute(builder: ((context) => SinglePage(censorCode: censorList[index]))));
              }),
            ),
          );
        }));
  }

  Widget censorMultiListTab() {
    return ListView.builder(
        itemCount: censorList.isEmpty ? 0 : censorList.length,
        itemBuilder: ((context, index) {
          return Card(
            child: ListTile(
              title: Text(censorList[index]),
              onTap: (() {
                Navigator.push(context, MaterialPageRoute(builder: ((context) => MultiPage(censorCode: censorList[index]))));
              }),
            ),
          );
        }));
  }

  Widget searchFormTab(){
    return Column(
      children: [
        TextField(
          controller: searchCtrl,
          decoration: const InputDecoration(
            border: OutlineInputBorder(), hintText: 'กรุณากรอกชื่อ Sensor'
          ),
        ),
        ElevatedButton(onPressed: (() {
          if (searchCtrl.text.isNotEmpty){
            setState(() {
              runState = true;
              searchCensorData();
            });
          }
        }), child: const Text('Search')),
        runState ? searchDataTable() : Container()
      ],
    );
  }

  Widget searchDataTable(){
    return Expanded(
      child: FutureBuilder(
          future: searchCensorData(),
          builder: ((context, snapshot) {
            if (snapshot.hasData) {
              return SingleChildScrollView(
                child: DataTable(
                  columns: const <DataColumn>[
                    DataColumn(
                      label: Expanded(
                        child: Text(
                          'Code',
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Expanded(
                        child: Text(
                          'Title',
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Expanded(
                        child: Text(
                          'Temp',
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Expanded(
                        child: Text(
                          'Humidity',
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Expanded(
                        child: Text(
                          'Timestamp',
                          style: TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                  ],
                  rows: snapshot.data!.map((e) => DataRow(cells: [
                    DataCell(Text(e.code)),
                    DataCell(Text(e.title)),
                    DataCell(Text(e.temperature)),
                    DataCell(Text(e.humidity)),
                    DataCell(Text(e.timestamp)),
                  ])).toList(),
                ),
              );
            } else {
              return const Center(child: CircularProgressIndicator());
            }
          })),
    );
  }
}
