import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:iotapp/sensor.dart';
import 'package:http/http.dart' as http;

class MultiPage extends StatefulWidget {
  const MultiPage({super.key, required this.censorCode});
  final String censorCode;

  @override
  State<MultiPage> createState() => _MultiPageState();
}

class _MultiPageState extends State<MultiPage> {
  late String censorCode;
  var baseURL = Sensor.baseURL;

  Future<List<Sensor>> getCensorData() async {
    List<Sensor> censorMulti = [];
    List<Sensor> censorFromJson(String body) => List<Sensor>.from(jsonDecode(body).map((x) => Sensor.fromJson(x)));

    final url = Uri.http(baseURL, '/sensor-current-multiple/$censorCode');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      var resBody = censorFromJson(utf8.decode(response.bodyBytes));

      for (var item in resBody){
        censorMulti.add(item);
      }

    } else {
      throw Exception('Failed');
    }
    return censorMulti;
  }

  @override
  void initState() {
    censorCode = widget.censorCode;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Multi Data $censorCode'),
      ),
      body: multiData(),
    );
  }

  Widget multiData() {
    return FutureBuilder(
        future: getCensorData(),
        builder: ((context, snapshot) {
          if (snapshot.hasData) {
            return SingleChildScrollView(
              child: DataTable(
                columns: const <DataColumn>[
                  DataColumn(
                    label: Expanded(
                      child: Text(
                        'Code',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Expanded(
                      child: Text(
                        'Title',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Expanded(
                      child: Text(
                        'Temp',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Expanded(
                      child: Text(
                        'Humidity',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Expanded(
                      child: Text(
                        'Timestamp',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                ],
                rows: snapshot.data!.map((e) => DataRow(cells: [
                  DataCell(Text(e.code)),
                  DataCell(Text(e.title)),
                  DataCell(Text(e.temperature)),
                  DataCell(Text(e.humidity)),
                  DataCell(Text(e.timestamp)),
                ])).toList(),
              ),
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        }));
  }
}
