package com.example.iotapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
