import requests

def post_data(data):
	# url = 'http://192.168.0.100:8000/api'
	url = 'http://127.0.0.1:8000/api'
	r = requests.post(url=url, json=data)
	print(r.text)


data = {'code': 'TM-101','title':'Temp1','temperature':21.9, 'humidity':51.9}
post_data(data)