from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
###############################
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
import json
from .serializers import TempHumidSerializer
###############################
from .models import TempHumid

def Home(request):
	return render(request, 'sensor/home.html')

def About(request):
	return render(request, 'sensor/about.html')

def History(request):

	data = TempHumid.objects.all().order_by('-id')
	#data = TempHumid.objects.filter(code='TM-102').order_by('-id')
	sensor = 'Temperature Sensor: #1'
	context = {'sensor':sensor, 'data':data}

	return render(request, 'sensor/history.html', context)


@api_view(['POST'])
def api_post_sensor(request):
	print('POST DATA from ESP32')

	if request.method == 'POST':
		ser = TempHumidSerializer(data=request.data)
		if ser.is_valid():
			ser.save()
			return Response(ser.data, status=status.HTTP_201_CREATED)
		return Response(ser.errors,status=status.HTTP_400_BAD_REQUEST)


##########API###########

def TestShowSensor(request):
	data = TempHumid.objects.all().order_by('-id')
	sensor_list = []
	sensor_dict = {}

	for d in data:
		if d.code not in sensor_list:
			sensor_list.append(d.code)
			print(d.__dict__)
			sensor_dict[d.code] = {'code':d.code,
								   'title':d.title,
								   'temperature':d.temperature,
								   'humidity':d.humidity,
								   'timestamp':d.timestamp.strftime('%Y-%m-%d %H:%M:%S')}

	return JsonResponse(sensor_dict,safe=True, json_dumps_params={'ensure_ascii':False})


def Sensor_list(request):
	data = TempHumid.objects.all()
	sensor_list = []
	for d in data:
		if d.code not in sensor_list:
			sensor_list.append(d.code)
	return JsonResponse(sensor_list,safe=False)

def Sensor_list_data(request):
	data = TempHumid.objects.all().order_by('-id')
	sensor_list = []
	sensor_dict = {}

	for d in data:
		if d.code not in sensor_list:
			sensor_list.append(d.code)
			print(d.__dict__)
			sensor_dict[d.code] = {'code':d.code,
								   'title':d.title,
								   'temperature':d.temperature,
								   'humidity':d.humidity,
								   'timestamp':d.timestamp.strftime('%Y-%m-%d %H:%M:%S')}

	return JsonResponse(sensor_dict,safe=True, json_dumps_params={'ensure_ascii':False})

def Sensor_current_single(request,CODE):
	data = TempHumid.objects.filter(code=CODE).order_by('-id')
	data = data[0]
	result = {'code':data.code,
		      'title':data.title,
		      'temperature':data.temperature,
		      'humidity':data.humidity,
		      'timestamp':data.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
	return JsonResponse(result,safe=True, json_dumps_params={'ensure_ascii':False})



def Sensor_current_multiple(request,CODE):
	data = TempHumid.objects.filter(code=CODE).order_by('-id')
	result_list = []

	for d in data:
		result = {'code':d.code,
			      'title':d.title,
			      'temperature':d.temperature,
			      'humidity':d.humidity,
			      'timestamp':d.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
		result_list.append(result)

	return JsonResponse(result_list[:10],safe=False, json_dumps_params={'ensure_ascii':False})


from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def Sensor_current_multiple_post(request,CODE):
	if request.method == 'POST':
		rawdata = request.POST.copy()
		print('RAW:',rawdata)
		if 'token' in rawdata:
			token = rawdata.get('token')
		else:
			return JsonResponse({'status':'no token'},safe=True, json_dumps_params={'ensure_ascii':False})

		token_list = ['abc123','xyz123']

		if token in token_list:
			data = TempHumid.objects.filter(code=CODE).order_by('-id')
			result_list = []

			for d in data:
				result = {'code':d.code,
					      'title':d.title,
					      'temperature':d.temperature,
					      'humidity':d.humidity,
					      'timestamp':d.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
				result_list.append(result)

			return JsonResponse(result_list[:10],safe=False, json_dumps_params={'ensure_ascii':False})

		return JsonResponse({'status':'invalid token error'},safe=True, json_dumps_params={'ensure_ascii':False})


	return JsonResponse({'status':'method not allow'},safe=True, json_dumps_params={'ensure_ascii':False})

