from django.contrib import admin
from .models import TempHumid

admin.site.register(TempHumid)

