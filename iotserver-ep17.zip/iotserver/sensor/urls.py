from django.urls import path
# from .views import Home, Table, api_post_sensor
from .views import *


urlpatterns = [
    path('', Home,name='home-page'),
    # localhost:8000/about
    # https://uncle-iot.com/about
    path('about/',About,name='about-page'),
    path('history/',History,name='history-page'),
    path('api', api_post_sensor),
]